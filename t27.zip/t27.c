#include "t27.h"

#define MAX_NODES 100
int char_to_index(char ch);
void find_most_frequent(const dict *node, const char *wd, char *current_word, int level, int *max_freq, char *max_word);

dict *dict_init(void)
{
    dict *node = (dict *)malloc(sizeof(dict)); // Allocate memory
    if (node == NULL)                          // Check the memory result
    {
        return NULL;
    }
    // initialise every node
    for (int i = 0; i < ALPHA; i++)
    {
        node->dwn[i] = NULL;
    }
    // initialise dwl
    node->up = NULL;        // up set NULL(Cause no parent)
    node->terminal = false; // terminal set false (Cause is not final node)
    node->freq = 0;         // freq set 0.
    return node;
}

bool dict_addword(dict *p, const char *wd)
{
    // return false if there's no word
    if (p == NULL || wd == NULL || wd[0] == '\0')
    {
        return false;
    }
    dict *current = p; // set temp p to point current node.
    // set every words
    for (int i = 0; wd[i] != '\0'; i++)
    {
        int index = char_to_index(wd[i]); // function char_to_index to storage.
        if (index == -1)
        {
            return false;
        }
        // check current node
        if (current->dwn[index] == NULL)
        {
            current->dwn[index] = dict_init(); // create new node
            current->dwn[index]->up = current; // set parent node to current node.
        }
        current = current->dwn[index]; // move to next node.
    }
    // Check if the word is already a terminal node
    if (current->terminal)
    {
        current->freq++; // Increment frequency
        return false;    // Indicate that this is a repeat
    }
    // mark as terminal node.
    current->terminal = true;
    current->freq += 1;
    return true;
}

void dict_free(dict **d)
{
    if (d == NULL || *d == NULL)
    {
        return;
    }

    // Release every child node before release current node
    for (int i = 0; i < ALPHA; i++)
    {
        if ((*d)->dwn[i] != NULL) // check whether node has child node
        {
            dict_free(&((*d)->dwn[i]));
        }
    }
    free(*d);
    *d = NULL;
}

int dict_wordcount(const dict *p)
{
    if (p == NULL)
    {
        return 0;
    }

    int count = 0;
    // Check whether current node is terminal or not？
    if (p->terminal)
    {
        count += p->freq; // Add current word into node
    }

    // Check current node's child is terminal or not?
    for (int i = 0; i < ALPHA; i++)
    {
        if (p->dwn[i] != NULL)
        {
            count += dict_wordcount(p->dwn[i]);
        }
    }
    return count;
}

int dict_nodecount(const dict *p)
{
    if (p == NULL)
    {
        return 0;
    }

    int count = 1;
    // loop all the child node
    for (int i = 0; i < ALPHA; i++)
    {
        if (p->dwn[i] != NULL)
        {
            count += dict_nodecount(p->dwn[i]);
        }
    }
    return count;
}

dict *dict_spell(const dict *p, const char *str)
{
    if (p == NULL || str == NULL || str[0] == '\0')
    {
        return NULL;
    }

    const dict *current = p; // start from root node.
    for (int i = 0; str[i] != '\0'; i++)
    {
        int index = char_to_index(str[i]);
        if (index == -1 || current->dwn[index] == NULL)
        {
            return NULL;
        }
        current = current->dwn[index];
    }

    // Check whether is terminal or not?
    if (current->terminal)
    {
        return (dict *)current; // return if terminal.
    }

    return NULL; // return null if not terminal
}

int dict_mostcommon(const dict *p)
{

    if (p == NULL)
    {
        return 0;
    }
    // Check current node
    int max_freq = 0;
    // if current is terminal and larger than max_freq
    if (p->terminal)
    {
        if (p->freq > max_freq)
        {
            max_freq = p->freq;
        }
    }

    for (int i = 0; i < ALPHA; i++)
    {
        if (p->dwn[i] != NULL)
        {
            int child_max_freq = dict_mostcommon(p->dwn[i]);
            if (child_max_freq > max_freq)
            {
                max_freq = child_max_freq;
            }
        }
    }

    return max_freq;
}

// CHALLENGE1
unsigned dict_cmp(dict *p1, dict *p2)
{
    // return 0 if p1 or p2 is NULL
    if (p1 == NULL || p2 == NULL)
    {
        return 0;
    }
    // Record p1's path
    dict *path1[MAX_NODES]; // create a path for p1
    int len1 = 0;

    dict *current = p1; // start from p1
    while (current != NULL)
    {
        path1[len1++] = current; // record node
        current = current->up;   // move up
    }

    // Record p2's path
    dict *path2[MAX_NODES]; // create a path for p2
    int len2 = 0;
    current = p2; // start from p2
    while (current != NULL)
    {
        path2[len2++] = current; // record node
        current = current->up;   // move up
    }
    // Find common path
    int i = len1 - 1, j = len2 - 1;

    while (i >= 0 && j >= 0 && path1[i] == path2[j])
    {
        i--;
        j--;
    }

    // Calculate the length of path
    int p1_to_com = i + 1; // remain path for p1
    int p2_to_com = j + 1; // remain path for p2

    return p1_to_com + p2_to_com; // All path
}

// CHALLENGE2
void dict_autocomplete(const dict *p, const char *wd, char *ret)
{
    if (p == NULL || wd == NULL)
    {
        ret[0] = '\0';
        return;
    }

    const dict *current = p; // start from root
    for (int i = 0; wd[i] != '\0'; i++)
    {
        int index = char_to_index(wd[i]);
        if (index == -1 || current->dwn[index] == NULL)
        {
            ret[0] = '\0';
            return;
        }
        current = current->dwn[index];
    }

    int max_freq = 0;
    char max_word[MAX_NODES] = "";
    char current_word[MAX_NODES] = "";
    strcpy(current_word, wd);
    find_most_frequent(current, wd, current_word, strlen(wd), &max_freq, max_word);

    // return word that need to be filled.
    strcpy(ret, max_word + strlen(wd));
}
int char_to_index(char ch)
{
    if (ch == '\'')
    {
        return ALPHA - 1; // if word is \, return last number (26)
    }
    else if (ch >= 'a' && ch <= 'z')
    {
        return ch - 'a'; // Return lowercase word.
    }
    else if (ch >= 'A' && ch <= 'Z')
    {
        return ch - 'A'; // Return uppercase word.
    }
    return -1; // return -1 for invalid char.
}
void find_most_frequent(const dict *node, const char *wd, char *current_word, int level, int *max_freq, char *max_word)
{
    if (node == NULL)
    {
        return;
    }

    // update freq if is terminal
    if (node->terminal)
    {
        if (strcmp(wd, current_word) != 0) // Don't do anything if current word is same.
        {
            if (node->freq > *max_freq ||
                (node->freq == *max_freq && strcmp(current_word, max_word) < 0))
            {
                *max_freq = node->freq;
                strcpy(max_word, current_word); // update word with front.
            }
        }
    }

    for (int i = 0; i < ALPHA; i++)
    {
        if (node->dwn[i] != NULL)
        {
            if (i == ALPHA - 1)
            {
                current_word[level] = '\'';
            }
            else
            {
                current_word[level] = 'a' + i;
            }
            current_word[level + 1] = '\0';
            find_most_frequent(node->dwn[i], wd, current_word, level + 1, max_freq, max_word);
            current_word[level] = '\0';
        }
    }
}

void test(void)
{
    // Test char_to_index
    assert(char_to_index('a') == 0);
    assert(char_to_index('z') == 25);
    assert(char_to_index('B') == 1);
    assert(char_to_index('Y') == 24);
    assert(char_to_index('\'') == 26);
    assert(char_to_index('8') == -1);
    assert(char_to_index('!') == -1);
}
