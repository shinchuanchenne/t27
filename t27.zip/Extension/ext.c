#include "ext.h"

dict *dict_init(void)
{
    // Allocate memory
    dict *node = (dict *)malloc(sizeof(dict));
    if (node == NULL)
    {
        return NULL; // Return NULL if allocation fails.
    }
    // Initialise the dict's head pointer to NULL.
    node->head = NULL;
    return node;
}
bool dict_addword(dict *p, const char *wd)
{
    // return false if dictionary or word is NULL
    if (p == NULL || wd == NULL || wd[0] == '\0')
    {
        return false;
    }
    // Convert the input word to lowercase
    char *low_wd = malloc(strlen(wd) + 1); // Allocate memory for the lowercase word.
    if (low_wd == NULL)
    {
        return false;
    }
    for (int i = 0; wd[i] != '\0'; i++)
    {
        low_wd[i] = tolower(wd[i]);
    }
    low_wd[strlen(wd)] = '\0';
    // Check if the word has already exists in the dict.
    struct node *current = p->head; // head of the linked list
    while (current != NULL)
    {
        if (strcmp(current->word, low_wd) == 0) // If found match word, increase frequency

        {
            current->frequency++;
            free(low_wd); // Free the temporary lowercase string
            return true;
        }
        current = current->next; // Move to next node
    }
    // Create a new node if word doesn't exist.
    struct node *new_node = malloc(sizeof(struct node));
    if (new_node == NULL)
    {
        free(low_wd); // Free the temporary lowercase string
        return false;
    }
    new_node->word = low_wd; // Assign the word to the new node
    new_node->frequency = 1; // Set initial to 1
    new_node->next = p->head;
    p->head = new_node;

    return true;
}

int dict_wordcount(const dict *p)
{
    // Return 0 if NULL
    if (p == NULL)
    {
        return 0;
    }
    int count = 0; // Set counter

    struct node *current = p->head;
    while (current != NULL)
    {
        count += current->frequency; // Adding frequency
        current = current->next;     // Move to next node
    }
    return count;
}

dict *dict_spell(const dict *p, const char *str)
{
    if (p == NULL || str == NULL)
    {
        return NULL;
    }
    // Convert input word to lower-case
    char *low_str = malloc(strlen(str) + 1); // Allocate memory for the low-case word.
    if (low_str == NULL)
    {
        return NULL;
    }
    for (int i = 0; str[i] != '\0'; i++)
    {
        low_str[i] = tolower(str[i]);
    }
    low_str[strlen(str)] = '\0';
    // Search for the word
    struct node *current = p->head; // Start from the head of the list
    while (current != NULL)
    {

        if (strcmp(current->word, low_str) == 0)
        {
            free(low_str);
            return (dict *)current; // Return node containing word if found.
        }
        current = current->next; // Move to the next node
    }
    free(low_str); // Free the string and return NULL if not found.
    return NULL;
}

void dict_free(dict **p)
{
    if (p == NULL)
    {
        return; // Nothing to free
    }
    struct node *current = (*p)->head; // Start from the head of the list
    while (current != NULL)
    {
        struct node *temp = current->next; // Storage the pointer to the next node.
        free(current->word);               // Free the memory allocated
        free(current);                     // Free the node
        current = temp;                    // Move to the next node.
    }
    free(*p);  // Free all the dictionary itself
    *p = NULL; // Set pointer to NULL
}

int dict_mostcommon(const dict *p)
{
    if (p == NULL)
    {
        return 0;
    }
    int max_frequency = 0; // Set max_frequency variable to track.

    struct node *current = p->head; // Start from the head
    while (current != NULL)
    {
        if (current->frequency > max_frequency) // Check current frequency is greater than max
        {
            max_frequency = current->frequency; // Update if greater
        }
        current = current->next; // Move to the next node
    }
    return max_frequency;
}

void test(void)
{
    dict *d = dict_init();
    assert(d != NULL);
    assert(d->head == NULL);

    // Test dict_addword
    assert(dict_addword(d, "January"));
    assert(dict_addword(d, "january") == 1);
    assert(dict_addword(d, "february"));
    assert(dict_addword(d, "FEBruary"));
    assert(dict_addword(d, "March"));
    assert(dict_addword(d, "March's"));

    // Test dict_wordcount
    assert(dict_wordcount(d) == 6);

    // Test dict_spell
    assert(dict_spell(d, "january") != NULL);
    assert(dict_spell(d, "JANUARY") != NULL);
    assert(dict_spell(d, "February") != NULL);
    assert(dict_spell(d, "March's") != NULL);
    assert(dict_spell(d, "april") == NULL);

    // Test dict_mostcommon
    assert(dict_mostcommon(d) == 2);

    // Test dict_free
    dict_free(&d);
    assert(d == NULL);
}