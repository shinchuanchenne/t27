#include "ext.h"

dict *dict_init(void)
{
    // Allocate memory
    dict *node = (dict *)malloc(sizeof(dict));
    if (node == NULL)
    {
        return NULL;
    }
    // Initialise
    node->head = NULL;
    return node;
}
bool dict_addword(dict *p, const char *wd)
{
    // return false if there's no word
    if (p == NULL || wd == NULL || wd[0] == '\0')
    {
        return false;
    }

    // Convert the input word to lowercase
    char *lowercase = malloc(strlen(wd) + 1);
    if (lowercase == NULL)
    {
        return false;
    }
    for (int i = 0; wd[i] != '\0'; i++)
    {
        lowercase[i] = tolower(wd[i]);
    }
    lowercase[strlen(wd)] = '\0';

    // Check whether this wd is inside
    struct node *current = p->head;

    while (current != NULL)
    {
        // If found match word, add frequency
        if (strcmp(current->word, lowercase) == 0)
        {
            current->frequency++;
            free(lowercase); // Free the temporary lowercase string
            return true;
        }
        // Move to next node
        current = current->next;
    }

    // Copy new node
    struct node *new_node = malloc(sizeof(struct node));
    if (new_node == NULL)
    {
        free(lowercase); // Free the temporary lowercase string
        return false;
    }
    new_node->word = lowercase; // Assign the lowercase string to the new node
    new_node->frequency = 1;
    new_node->next = p->head;
    p->head = new_node;

    return true;
}

int dict_wordcount(const dict *p)
{
    // Return 0 if NULL
    if (p == NULL)
    {
        return 0;
    }
    int count = 0; // Set counter

    struct node *current = p->head;
    while (current != NULL)
    {
        count += current->frequency; // Adding frequency
        current = current->next;     // Move to next node
    }
    return count;
}

dict *dict_spell(const dict *p, const char *str)
{
    if (p == NULL || str == NULL)
    {
        return NULL;
    }

    // 將輸入單詞轉為小寫
    char *lowercase = malloc(strlen(str) + 1);
    if (lowercase == NULL)
    {
        return NULL;
    }
    for (int i = 0; str[i] != '\0'; i++)
    {
        lowercase[i] = tolower(str[i]);
    }
    lowercase[strlen(str)] = '\0';

    // 遍歷鏈結串列
    struct node *current = p->head;
    while (current != NULL)
    {

        if (strcmp(current->word, lowercase) == 0)
        {
            free(lowercase); // 釋放小寫字串
            return (dict *)current;
        }
        current = current->next;
    }

    free(lowercase); // 釋放小寫字串
    return NULL;
}

void dict_free(dict **p)
{
    if (p == NULL)
    {
        return;
    }
    struct node *current = (*p)->head;
    while (current != NULL)
    {
        struct node *temp = current->next;
        free(current->word);
        free(current);
        current = temp;
    }
    free(*p);
    *p = NULL;
}

int dict_mostcommon(const dict *p)
{
    if (p == NULL)
    {
        return 0;
    }
    int max_frequency = 0;

    struct node *current = p->head;
    while (current != NULL)
    {
        if (current->frequency > max_frequency)
        {
            max_frequency = current->frequency;
        }
        current = current->next;
    }
    return max_frequency;
}

void test(void)
{
    dict *d = dict_init();
    assert(d != NULL);
    assert(d->head == NULL);

    // Test dict_addword
    assert(dict_addword(d, "Apple"));      // 插入單詞
    assert(dict_addword(d, "apple") == 1); // 重複插入應更新頻率
    assert(dict_addword(d, "banana"));     // 插入另一個單詞
    assert(dict_addword(d, "BANANA"));     // 重複插入另一個單詞（大小寫不敏感）
    assert(dict_addword(d, "cherry"));
    assert(dict_addword(d, "banana's")); // 插入帶撇號的單詞

    // Test dict_wordcount
    assert(dict_wordcount(d) == 6); // 頻率應為 Apple(2) + Banana(2) + Cherry(1) + Banana's(1)

    // Test dict_spell
    assert(dict_spell(d, "apple") != NULL);    // 查詢應返回非空
    assert(dict_spell(d, "APPLE") != NULL);    // 大小寫不敏感查詢
    assert(dict_spell(d, "Banana") != NULL);   // 查詢成功
    assert(dict_spell(d, "banana's") != NULL); // 帶撇號查詢成功
    assert(dict_spell(d, "Orange") == NULL);   // 不存在的單詞應返回空

    // Test dict_mostcommon
    assert(dict_mostcommon(d) == 2); // Apple 和 Banana 是最常見的單詞

    // Test dict_free
    dict_free(&d);
    assert(d == NULL); // 釋放後應該為 NULL
}