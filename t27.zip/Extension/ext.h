#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

// 26 letters, plus the '
#define ALPHA 27

struct node
{
   char *word;
   int frequency;
   struct node *next;
};

struct dict
{
   struct node *head;
};
typedef struct dict dict;

// Creates new dictionary
dict *dict_init(void);
bool dict_addword(dict *p, const char *str);
int dict_wordcount(const dict *p);
dict *dict_spell(const dict *p, const char *str);
void dict_free(dict **p);
int dict_mostcommon(const dict *p);
void test(void);
